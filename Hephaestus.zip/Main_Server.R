# Library
library(DT)
library(data.table)


# Calling Scripts with functions
source('serverFunctions/fetchData.R', local = TRUE)

# Server Function
Main_Server <- function(input,output,session){
  
  # Reactive Values
  values <- reactiveValues(eset = NULL)
  values2 <- reactiveValues(renderedDataset = NULL)
  
  # fetchEvent
  observeEvent(input$fetch, {values$eset <- fetchData(input$goId,input$plId)})
  
  # Display Event
  observeEvent(input$fetch, {values2$renderedDataset <- paste("Showing MetaData for", input$goId, sep = " ")})
  
  # Rendering text for display
  output$renderedDataset <- renderText({values2$renderedDataset})
  
  # Rendering table for display
  output$eset <- renderDT({datatable(values$eset$disp_p_data,rownames = FALSE)})
  
  # Download for fetched datasets
  output$downData <- downloadHandler(
    filename = function() {paste(input$goId, "_",input$downSel, ".csv", sep = "")},
    content = function(file) {fwrite(as.data.frame(values$eset[[input$downSel]]), sep = ",", file)}
  )
  
  # Tab Switch
  observeEvent(input$jumpToStats, {
    updateTabsetPanel(session, "inTabset", selected = "Satistics")
  })
}