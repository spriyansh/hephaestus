# Loading Libraries
library("shiny")
library("shinythemes")
library("DT")



# Calling Scripts with functions
source('uiFunctions/dataFerry.R', local = TRUE)

Main_UI <- shinyUI({
  fluidPage(theme = shinytheme("flatly"),# fluidPage-cont
            navbarPage(title="Hephaestus",id = "inTabset",# navbarPage-cont
                                   tabPanel("Home"),# tabPanel-1-close
                                   dataFerry(),# tabPanel-2-close
                                   tabPanel("Satistics", value = "Satistics"),# tabPanel-3-close
                                   tabPanel("Visuals"),# tabPanel-4-close
                                   tabPanel("Speculate"),# tabPanel-5-close
                                   tabPanel("Contact")# tabPanel-6-close
                                   ) # navbarPage-close
            )# fluidPage-close
  }) #function-close