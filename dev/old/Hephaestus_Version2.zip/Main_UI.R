# Loading Libraries
library("shiny")
library("shinythemes")
library("DT")



# Calling Scripts with functions
source('uiFunctions/dataFerry.R', local = TRUE)

Main_UI <- shinyUI({
  fluidPage(theme = shinytheme("flatly"),# fluidPage-cont
            navbarPage(title="Hephaestus",id = "inTabset",# navbarPage-cont
                                   tabPanel("Home"),# tabPanel-1-close
                                   dataFerry(),# tabPanel-2-close
                                   tabPanel("Satistics", value = "Satistics",
                                            fluidRow(tags$h2("Derive Statistical Inferences form Expression Counts")),
                                            tabsetPanel(
                                              tabPanel("Analyze Fetched Data",br(),
                                              DT::dataTableOutput("previous"),
                                              tags$h5("Samples Selected for 'Experiment-Group'"),
                                              verbatimTextOutput("SampleG1"),
                                              tags$h5("Samples Selected for 'Control-Group'"),
                                              verbatimTextOutput("SampleG2"),hr(),br(),
                                              tags$h4("Select the Groups: "),
                                              actionButton("experiment", label = "Step-1: Mark as Experimental Group"),
                                              actionButton("clear", label = "Step-2: Clear Selection"),
                                              actionButton("control", label = "Step-3: Mark as Control Group"),hr(),br(),
                                              tags$h4("Proceed for Hypothesis testing: "),
                                              numericInput("pvalue", "Set P-Value", 0.03, min = 0.01, max = 0.05),
                                              numericInput("apvalue", "Set Adjusted-P-Value", 0.03, min = 0.01, max = 0.05),br(),
                                              radioButtons("outType", c("Select the Output Type: "), choices = c("Differential Gene-Symbols" = TRUE,"Differential Probe IDs" = FALSE),
                                                           selected = TRUE),
                                              actionButton("analyze", "Analyze"),
                                              DT::dataTableOutput("temp"),
                                              downloadButton("donwloadDE", "Download Results"), br()
                                          
                                      ),tabPanel("Upload and Analyze"))),# tabPanel-3-close
                                   tabPanel("Visuals"),# tabPanel-4-close
                                   tabPanel("Speculate"),# tabPanel-5-close
                                   tabPanel("Contact")# tabPanel-6-close
                                   ) # navbarPage-close
            )# fluidPage-close
  }) #function-close